
package com.riesgos.backend.riesgosapp.backend_riesgosapp.services.interfaces;

import java.util.List;
import com.riesgos.backend.riesgosapp.backend_riesgosapp.models.entities.MedioConservacion;

public interface IMedioConservacionService {
    List<MedioConservacion> findAll();
    MedioConservacion save(MedioConservacion entity);
    void deleteById(Integer id);
}

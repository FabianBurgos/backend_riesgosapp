package com.riesgos.backend.riesgosapp.backend_riesgosapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendRiesgosappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendRiesgosappApplication.class, args);
	}

}
